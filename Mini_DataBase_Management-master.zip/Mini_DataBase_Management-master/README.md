# DataBase_Management_System
Made using only C++ language.
